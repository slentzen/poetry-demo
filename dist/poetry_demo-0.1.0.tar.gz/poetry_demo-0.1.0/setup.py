# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['poetry_demo']

package_data = \
{'': ['*']}

install_requires = \
['black>=22.12.0,<23.0.0', 'pendulum>=2.1.2,<3.0.0', 'pytest>=7.2.0,<8.0.0']

entry_points = \
{'console_scripts': ['my-script = poetry-demo:main']}

setup_kwargs = {
    'name': 'poetry-demo',
    'version': '0.1.0',
    'description': '',
    'long_description': '',
    'author': 'John Doe',
    'author_email': 'johndoe@mail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.11,<4.0',
}


setup(**setup_kwargs)
